namespace P01_StudentSystem.Data.Models.Enums;

public enum ResourceTypeEnum
{
    Video,
    Presentation,
    Document,
    Other

}