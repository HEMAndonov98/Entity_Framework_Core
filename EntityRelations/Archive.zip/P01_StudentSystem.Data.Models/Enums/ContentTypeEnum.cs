namespace P01_StudentSystem.Data.Models.Enums;

public enum ContentTypeEnum
{
    Application,
    Pdf,
    Zip
}